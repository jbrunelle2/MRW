<?php
	//ini_set('display_errors',1);
	//error_reporting(E_ALL);
require_once("phpscripts/init.php");
//call to function to check if logged in
//confirm_logged_in();

//Login would need to be rigged, due Week feb 13th

//Check to see if someone clicked on submit button
if(isset($_POST['submit'])) {
	echo "works";
	
	$fname = trim($_POST['fname']);
	$lname = trim($_POST['lname']);
	$username = trim($_POST['username']);
	$password = trim($_POST['password']);
	$level = $_POST['lvllist'];
	
	if(empty($level)) {
		echo "Level Not Selected";
		$message = "Please select a user level.";
	}else{
		echo "Level Selected";
		$result = createUser($fname, $lname, $username, $password, $level);
		
		$message = $result;
	}
}
?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Create User</title>
<link href="css/main.css" rel="stylesheet" type="text/css" media="screen">
</head>

<body>
<h1>Create User</h1>
<?php if(!empty($message)){echo $message;}?>
<form id="panelCon" action="admin_createuser.php" method="post">
<label for="">First Name:</label>
<input name="fname" type="text" value="<?php if(!empty($fname)){echo $fname;}?>"><br>
<label for="">Last Name:</label>
<input name="lname" type="text" value="<?php if(!empty($lname)){echo $lname;}?>"><br>
<label for="">User Name:</label>
<input name="username" type="text" value="<?php if(!empty($username)){echo $username;}?>"><br>
<label for="">Password:</label>
<input name="password" type="text" value="<?php if(!empty($password)){echo $password;}?>"><br>
<!--created password but system should generate-->
<br><br>
<select name="lvllist">
	<option value="">*Please Select User Level*</option>
    <option value="2">Web Admin</option>
    <option value="1">Web Master</option>
</select>
<br><br>
<input type="submit" name="submit" value="Create User">
</form>
<br><br>
<a href="admin_index.php">< Back to Admin Panel</a>

</body>
</html>