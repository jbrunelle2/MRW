<?php
	require_once('phpscripts/init.php');
	confirm_logged_in();
	//$info = "SELECT * FROM `tbl_timestamp`";
	//$last_login_date = $info['last_login_date']; // get last_login_date from mysql table
 	//$last_login_time = $info['last_login_time']; // get last_login_time from mysql table
	
?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Admin Panel</title>
<link href="css/main.css" rel="stylesheet" type="text/css" media="screen">

</head>
<body>
<div id="panelCon">
	<h1>Welcome <?php echo $_SESSION['users_name']; ?> to your admin panel</h1>
    <a href="admin_createuser.php">Create User</a>
    <a href="admin_edituser.php">Edit User</a>
	<!--<h3>You last signed in on <?php //echo $last_login_date; ?> at <?php //echo $last_login_time; ?>.</h3>-->
	<br>
	<a href="phpscripts/caller.php?caller_id=logout">Log Out</a>
	</div>
</body>
</html>