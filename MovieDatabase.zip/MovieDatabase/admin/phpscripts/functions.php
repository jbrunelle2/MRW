<?php
	
	function redirect_to($location) {
		if($location != NULL) {
			header("Location: {$location}");
			exit;
		}
	}
	
	function addMovie($fimg, $thumb, $title, $year, $storyline, $runtime, $trailer, $price, $cat){
		include('connect.php');
		$fimg = mysqli_real_escape_string($link, $fimg);
		
		if($_FILES['movie_fimg']['type'] == "image/jpg" || $_FILES['movie_fimg']['type'] == "image/jpeg"){ //Type is image, extension is jpg, it's not a directory. jpeg also exists, so check for both.
			$targetpath = "../images/{$fimg}"; //where is this getting uploaded to. pathing must go up from the file folder, into the level above, and then into
			if(move_uploaded_file($_FILES['movie_fimg']['tmp_name'], $targetpath)){ //move file into folder, was it successful? Can it be written? Yes? Execute rest of code in this condition. tmp name assigns a temporary path and file name. It doesn't send straight to images, puts in temp directory that gets emptied if something fails. once all checks are done, it moves into folder.
				//duplicate file for thumbnail resizing. Run command below to take a file and copy it. They are exactly the same size right now, but one is renamed with TH_
				$orig = "../images/".$fimg;
				$th_copy = "../images/".$thumb;
				
			if(!copy($orig, $th_copy));{
				//echo "Failed to copy...";
				}
				
				//$size = getimagesize($orig);
				//echo $size[0]." x ".$size[1];
				
				$qstring = "INSERT INTO tbl_movies VALUES(NULL,'{$thumb}','{$fimg}','noBG.jpg','{$title}','{$year}','{$storyline}','{$runtime}','{$trailer}','{$price}')";
				//echo $qstring;
					//Make sure the above query is working...
				$result = mysqli_query($link,$qstring);
				
				if($result==1){
					$qstring2 = "SELECT * FROM tbl_movies ORDER BY movies_id DESC LIMIT 1";
					//If 2 people enter movies, if two people at the same time do this, this query won't work well. If this was facebook,  you'd want to make more checks. For a small system this is
					//okay.
					$result2 = mysqli_query($link, $qstring2);
						//Grabs info from the above query
					$row = mysqli_fetch_array($result2);
						//Asks for the result of that query here.
					$lastID = $row['movies_id'];
						
					$qstring3 = "INSERT INTO tbl_l_mc VALUES(NULL,'{$lastID}','{$cat}')";
					//insert into linking table
					$result3 = mysqli_query($link,$qstring3);
					
				}
				redirect_to("admin_index.php");
			}
		}
		
		//have to run a clean on this; whenever you're inserting into a database, escapestring it so no special characters are being injected. Injections could be put in file names, strings, etc.
		// do on create user fields too? Well, yes, but it's a minor thing at that point. 
		
		//Have to run checks to make sure images being moved, you can chance it, but you can figure out where most events will occur and target before it reaches database.
		//set permission to folder so that an executable cannot run from folder. Do this to images, in permissions while hosted. Double check the hosted state of read/write.
		mysqli_close($link);
		}
	
?>