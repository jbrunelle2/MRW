<?php

	function logIn($username, $password, $ip){
		require_once('connect.php');
			$username = mysqli_real_escape_string($link, $username);
			$password = mysqli_real_escape_string($link,$password);//cleans string, removes slashes quotes etc.
			$loginString = "SELECT * FROM tbl_user WHERE  user_name='{$username}' AND user_pass='{$password}'"; 
			//echo $loginString;	
			$user_set = mysqli_query($link, $loginString);
			
			if(mysqli_num_rows($user_set)){
				$found_user = mysqli_fetch_array($user_set, MYSQLI_ASSOC);
				$id = $found_user['user_id'];
				//session variable = temporary global variable
				$_SESSION['users_id'] = $id;
				$_SESSION['users_name'] = $found_user['user_name'];
				if(mysqli_query($link, $loginString)){
					$updateString = "UPDATE tbl_user SET user_ip = '{$ip}' WHERE user_id={$id}";
					$updateQuery = mysqli_query($link, $updateString);
					$check = $found_user['user_lastlogin'];
					//First Time Login Checks
					//http://stackoverflow.com/questions/5676562/php-first-time-login-page
					//Checks to see if initial value has changed, and changes value on initial login. The page will redirect based on the value of that function as well.
					if($check == '1'){
					$updateloginString = "UPDATE tbl_user SET user_lastlogin = '2' WHERE user_id={$id}";
					$updateloginQuery = mysqli_query($link, $updateloginString);
					redirect_to("admin_edituser.php");
					}
					
				}
				redirect_to("admin_index.php");
			}else{
				$message = "Username/Password where incorrect. <br>Please make sure your caps lock key is turned off.";
				return $message;
			}
		
		mysqli_close($link);
	}



?>