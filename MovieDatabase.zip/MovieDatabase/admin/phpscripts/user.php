<?php

//if($string['tbl_row'(Webmaster/Admin) is == '1']) {do not allow delete function to fire.} Need to define a string containing the webmaster/admin information.

	function deleteUser($id){
		include ('connect.php');
		
		$delstring = "DELETE FROM tbl_user WHERE user_id={$id}";
		$delquery = mysqli_query($link, $delstring);
		
		if($delquery){
			redirect_to("../admin_index.php");
		}else{
			$message = "This user cannot be deleted.";
			echo $message;
		}
		
		mysqli_close($link);	
	}

	function editUser($id, $fname, $lname, $username, $password) {
			include('connect.php');
				//So it's calling to connect.php twice on this page and it can't deal with require_once again, so we use include instead
			$updatestring = "UPDATE tbl_user SET user_fname='{$fname}', user_lname='{$lname}', user_name='{$username}', user_pass='{$password}' WHERE user_id={$id}";
			$updatequery = mysqli_query($link, $updatestring);
			
			if($updatequery) {
				redirect_to("admin_index.php");
			} else {
				$message = "Critical error, erasing all databases in 3....2.....1..... Just Kidding, there was a problem changing your user account settings. Please contact the admin.";
			}
		
		
	mysqli_close($link);
	}

	
	function getUser($id) {
		require_once('connect.php');
		$userstring = "SELECT * FROM tbl_user WHERE user_id={$id}";
		$userquery = mysqli_query($link, $userstring);
			//echo $userquery;
		//write user string to get that person's account from the query, if successful fetch it and return it to popform.
		if($userquery) {
			//fetch
			$found_user = mysqli_fetch_array($userquery, MYSQLI_ASSOC);
			//return to popform
			return $found_user;
			}else{
				$message = "There was an error in changing the account. Please contact the web admin for help.";
				return $message;
			}
		
		mysqli_close($link);
	}

	function createUser($fname, $lname, $username, $password, $level){
		require_once("connect.php");
		$ip = 0;
		$userstring = "INSERT INTO tbl_user VALUES(NULL, '{$fname}','{$lname}','{$username}','{$password}','{$level}','{$ip}')"; 
	 	//echo $userstring;
		//A couple rules when creating: the number of items in the db needs to be represented by the number of htings we pass it. IF there are 10 things and we pass it 9 or 11 it will fail. They need to be in order, as well; the order of the database itself. Order matters. If you feed last name before first name, it will fk up. We're passing null as a placeholder, "Do whatever I was told to do in this spot". 
		$userquery = mysqli_query($link, $userstring);
		if($userquery){
			redirect_to("admin_index.php");
		}else{
			$message = "There was an error in creating this user, please try again later...";
			return $message;
		}
		mysqli_close($link);
}
?>