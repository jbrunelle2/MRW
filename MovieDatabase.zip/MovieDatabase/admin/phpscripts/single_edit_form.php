<?php 
	
	function single_edit($tbl, $col, $id) {
		$result = getSingle($tbl,$col,$id); //this holds the information about the database (column names, field types, values, lengths)
		$getResult = mysqli_fetch_array($result); //this holds the information about the actual content (movies, runtime, etc)
		//This, when passed the proper parameters, will modify or edit any database.
		
		//some of the form below will be hardcoded, the majority iwll be dynamic. This form builds itself based on teh tables. Could set this in a session, on edit page call in session, but could have variable scope error due to common variable names like table. Another way we can use this is to pass it through the actual form itself, We want to make sure the end user does not see the next three inputs. The user should never be able to change a table, column, or id name. This method will package everything in the form.
		echo "<form action=\"phpscripts/edit.php\" method=\"post\">";
		echo "<input hidden name=\"tbl\" value=\"{$tbl}\">";
		echo "<input hidden name=\"col\" value=\"{$col}\">";
		echo "<input hidden name=\"id\" value=\"{$id}\">";
		
		//do a count against the object for the number of fields in there, then goes through object to pull out each field (column) directly, store it and write it out.
		
		for($i=0; $i<mysqli_num_fields($result); $i++){
			//echo $i;
			//go to first position in array, pull it out and count ten times. Want to know type and name of the column.
			//how can we dynamically create a query. We could use this method to make a create form. The end goal for this is editing.
			$dataType = mysqli_fetch_field_direct($result, $i);	
			$fieldName = $dataType->name;
			echo $fieldName."<br>";
			$fieldType = $dataType->type;
			echo $fieldType."<br>";
				//253 = variable character, 2 = smallint, 252=text, refer to database types. Would want to do a find and replace to fix up the below later
			if($fieldName != $col){
				echo "<label>{$fieldName}</label>";
				if($fieldType !=252){
					echo "<input type=\"text\" name=\"{$fieldName}\" value=\"{$getResult[$i]}\"><br><br>";
				}else{
					echo "<textarea name=\"$fieldName\">{$getResult[$i]}</textarea>";
				}
			}
		}
		echo "<input type=\"submit\" value=\"Save Changes\"><br>";
		echo "</form>";		
		
	}
	
?>