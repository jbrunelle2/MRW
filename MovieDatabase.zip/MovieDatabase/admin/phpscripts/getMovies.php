<?php 
//Predictive/Live Search. Click on a product and open a lightbox - this is made through an ajax call going to a file like this and feeding that parameter back as an object. Clears the div instead of reloading the page.

	ini_set('display_errors',1);
	error_reporting(E_ALL);
	require_once('connect.php');
	//Working with JSON in PHP- this file can be used to set up live/predictive search
	
	if(isset($_GET['srch'])){ //change search to whatever gets passed in the url
		$srch = $_GET['srch'];
			$movieQuery = "SELECT movies_id, movies_title, movies_thumb, movies_year FROM tbl_movies WHERE movies_title LIKE '$srch%' ORDER BY movies_title ASC";
			$getMovies = mysqli_query($link,$movieQuery);
	}else{
	$movieQuery = "SELECT movies_id, movies_title, movies_thumb, movies_year FROM tbl_movies ORDER BY movies_title ASC";
	$getMovies = mysqli_query($link,$movieQuery);
	}
	//This method will write out all the form data for us
	$jsonResult="[";
	
	while($movieResult = mysqli_fetch_assoc($getMovies)){ //call in associative array, not fetch array. We want the label AND value for JSON. Fetch will only give value.
		$jsonResult.=json_encode($movieResult).","; //remember to remove last comma
	}
	
	$jsonResult.="]";
	//substr_replace(string,replace,start,length); //the string, what you want to replace, where to start, and the length in characters
	$jsonResult = substr_replace($jsonResult,'',-2,1); 
	echo $jsonResult;	
?>