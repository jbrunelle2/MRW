<?php
	ini_set('display_errors',1);
	error_reporting(E_ALL);
	//comment out or delete from file when live, for macs only. Customers only want people working in the CMS when they're at work, not from home computers. How to lock the CMS down so it only works from a certain location: an IP address. Easy to find out. We can take that number and on login we can check it and validate it. Tracking the IP address is a good thing, even if they allow logging in from anywhere. VPNs might be more problematic in this case.
	
	require_once("phpscripts/init.php");
	
	$ip = $_SERVER["REMOTE_ADDR"];
	//echo $ip;
	if(isset($_POST['submit'])) {
		//echo "Thanks for clicking";
		$username = trim($_POST['username']);
		$password = trim($_POST['password']);
		if($username != "" && $password != ""){
			$result = logIn($username, $password, $ip);
			$message = $result;
			}else{
			$message = "Please fill in the required fields.";
			}
	}
?>

<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Client Login</title>
<link href="css/main.css" rel="stylesheet" type="text/css" media="screen">
</head>
<body>
<div id="panelCon">
	<h1>Content Management System Login</h1>
    <?php if(!empty($message)){echo $message;}?>
    <!--We need an action and a method to make a form work-->
	<form action="admin_login.php" method="post">
		<label>Username:</label>
    	<input type="text" name="username" value="">
    	<br>
    	<label>Password:</label>
        <input type="password" name="password" value="">
        <input type="submit" name="submit" value="Go!">
    </form>
    </div>
</body>
</html>