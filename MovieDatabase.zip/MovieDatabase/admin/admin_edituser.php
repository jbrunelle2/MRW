<?php
	//ini_set('display_errors',1);
	//error_reporting(E_ALL);
require_once("phpscripts/init.php");
//call to function to check if logged in
//confirm_logged_in();

$id = $_SESSION['users_id']; //users_id might be user_id, double check
//echo $id; //log in and make sure the ID is showing at the top of the page.
$popForm = getUser($id);

//echo $popForm;

if(isset($_POST['submit'])) {
	echo "works";
	
	$fname = trim($_POST['fname']);
	$lname = trim($_POST['lname']);
	$username = trim($_POST['username']);
	$password = trim($_POST['password']);
	
	$result = editUser($id, $fname, $lname, $username, $password);
	$message = $result;
	}
?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Edit User</title>
<link href="css/main.css" rel="stylesheet" type="text/css" media="screen">
</head>

<body>
<h1>Edit User</h1>
<?php if(!empty($message)){echo $message;}?>
<form id="panelCon" action="admin_edituser.php" method="post">
<label for="">First Name:</label>
<input name="fname" type="text" value="<?php echo $popForm['user_fname']; ?>"><br>

<label for="">Last Name:</label>
<input name="lname" type="text" value="<?php echo $popForm['user_lname']; ?>"><br>

<label for="">User Name:</label>
<input name="username" type="text" value="<?php echo $popForm['user_name']; ?>"><br>

<label for="">Password:</label>
<input name="password" type="text" value="<?php echo $popForm['user_pass']; ?>"><br>

<br><br>
<input type="submit" name="submit" value="Edit User">
</form>
<br><br>
<a href="admin_index.php">< Back to Admin Panel</a>

</body>
</html>