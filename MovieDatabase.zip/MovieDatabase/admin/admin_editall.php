<?php 
	require_once("phpscripts/init.php");
	//confirm_logged_in();
	
	//ini_set('display_errors',1);
	//error_reporting(E_ALL);
	
	//We're hardcoding the below values, but you'd pass dynamically otherwise. This will build any query you want it to, this form will adapt to almost any content. Figure out how to adapt this to your needs.
	$tbl = "tbl_movies";
	$col = "movies_id";
	$id = 1;
?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Edit All</title>
</head>
<!--A form table name, column name and id, we can change any one of those to any different table/column/id, which will then put out a form for editing.-->
<body>
	<h1>Edit All</h1>
	<?php single_edit($tbl, $col, $id); ?>
	<a href="admin_index.php">Back</a>

</body>
</html>