<?php
	
	ini_set('display_errors',1);
    error_reporting(E_ALL);
	
	require_once('admin/phpscripts/init.php');

	if(isset($_GET['filter'])) {
		$tbl1 = "tbl_movies";
		$tbl2 = "tbl_cat";
		$tbl3 = "tbl_l_mc";
		$col1 = "movies_id";
		$col2 = "cat_id";
		$col3 = "cat_name";
		$filter = $_GET['filter'];
		$getMovies = filterType($tbl1, $tbl2, $tbl3, $col1, $col2, $col3, $filter);
	}else{
		$tbl = "tbl_movies";
		$getMovies = getAll($tbl);
	}

include "comment.class.php";
include'admin/phpscripts/connect.php';

/*
/	Select all the comments and populate the $comments array with objects
*/

$comments = array();
	$sql = "SELECT * FROM comments ORDER BY id ASC";
	$result = mysqli_query($link,$sql);

while($row = mysqli_fetch_assoc($result))
{
	$comments[] = new Comment($row);
}
?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>My Title</title>
<link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>
<h1>Movie Review Website</h1>
<?php
	include('includes/nav.html');
?>

<h2><a href="">Go Back&raquo;</a></h2>

<div id="vidCon">
<iframe src="https://www.youtube.com/embed/1LmPeHX7RRo" frameborder="0" allowfullscreen></iframe><!--Change to video player-->
</div>

<div id="main">

<div id="addCommentContainer">
	<p>Add a Comment</p>
	<form id="addCommentForm" method="post" action="">
    	<div>
        	<label for="name">Your Name</label>
        	<input type="text" name="name" id="name" />
            
            <label for="email">Your Email</label>
            <input type="text" name="email" id="email" />
     
            <label for="body">Comment Body</label>
            <textarea name="body" id="body" cols="20" rows="5"></textarea>
            
            <input type="submit" id="submit" value="Submit" />
        </div>
    </form>
</div>
<?php

/*
/	Output the comments one by one:
*/

foreach($comments as $c){
	echo $c->markup();
}

?>
</div>

<?php
	if(!is_string($getMovies)){
		while($row = mysqli_fetch_array($getMovies)){
			echo "<img src=\"images/{$row['movies_thumb']}\" alt=\"{$row['movies_title']}\">
				 <h2>{$row['movies_title']}</h2>
				 <p>{$row['movies_year']}</p><br>
				 <a href=\"details.php?id={$row['movies_id']}\">More...</a><br><br>";
		}
	}else{
		echo "<p>{$getMovies}</p>";
	}
	
	include('includes/footer.html');
?>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript" src="script.js"></script>
</body>
</html>